

from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    description='Search Tool for strings',
    author='John Doe',
    author_email='mail@mail.com',
    url='mysite.com',
    py_modules=['vsearch']
)
